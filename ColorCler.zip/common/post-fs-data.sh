#!/system/bin/sh

nohup /data/adb/modules/USB_CQ/service.sh > /dev/null 2>&1 &

