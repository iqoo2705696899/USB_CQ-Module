#!/system/bin/sh
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done
while true; do
    if dumpsys window | grep -q "mDreamingLockscreen=false"; then
        TWRP_PATHS="
        /data/recovery/
        /cache/recovery/
        /data/media/0/TWRP/
        /data/media/0/Han.GJZS/
        /data/media/0/recovery/
        /sdcard/TWRP/
        /sdcard/Han.GJZS/
        /sdcard/recovery/
        /storage/emulated/0/TWRP/
        /storage/emulated/0/Han.GJZS/
        /storage/emulated/0/recovery/
        "       
        for path in $TWRP_PATHS; do
            if [ -e "$path" ]; then               
                rm -rf "$path"
            fi
        done
        settings put global adb_enabled 0
        settings put global development_settings_enabled 0
        settings put global stay_on_while_plugged_in 0
        settings put global window_animation_scale 1
        settings put global transition_animation_scale 1
        settings put global animator_duration_scale 1
        
        if [ -e "/data/local/tests" ]; then
            rm -rf "/data/local/tmp"
            mv "/data/local/tests" "/data/local/tmp"
        fi
        
        break
    fi    
    sleep 1
done
